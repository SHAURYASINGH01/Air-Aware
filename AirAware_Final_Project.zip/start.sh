#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
python3 -m unittest tests.test_rules tests.test_live_aqi tests.test_api
python3 -m uvicorn backend.app:app --host 0.0.0.0 --port 8000
