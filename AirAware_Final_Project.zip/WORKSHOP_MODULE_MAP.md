# Workshop Module Map — AirAware

| Workshop concept | Project file | What it demonstrates | How to verify |
|---|---|---|---|
| First agent | `workshop_modules/01_first_agent.py` | Minimal Strands agent / Bedrock call | Run only after workshop credentials and model access are ready |
| Custom tool | `workshop_modules/02_custom_aqi_tool.py` | A deterministic AQI assessment function used as a tool | Read function docs and test rule outputs |
| Multi-agent swarm | `workshop_modules/03_multi_agent_swarm.py` | Analyst → planner → communicator specialist roles | Requires the installed Strands Swarm API and functioning Bedrock access |
| Backend API | `backend/app.py` | FastAPI `/api/health`, `/api/ask`, and `/api/air-quality` | Start server and open `/docs` or `/api/health` |
| Frontend | `frontend/index.html`, `style.css`, `script.js` | Responsive planner, air-context card, checklist, plan export/history, assistant | Open page or start FastAPI server |
| Rule tests | `tests/test_rules.py` | CPCB category boundary and advice tests | `python -m unittest tests.test_rules` |

## Data-source distinction

The planner classifies a reading that a user enters as an Indian CPCB AQI value. Open-Meteo air-quality context is a separate model-based data feed that exposes PM2.5, PM10 and U.S./European AQI indices. These are not CPCB station measurements, and U.S./European index values must not be displayed as Indian CPCB AQI. Open-Meteo documentation: https://open-meteo.com/en/docs/air-quality-api.

## Operational honesty

A healthy FastAPI route does not prove Bedrock access. A model call and, separately, the Swarm workflow must be tested in the actual workshop environment before claiming they ran successfully. Review the installed Strands SDK version for compatibility; module examples are learning materials, not proof that model permissions exist.
