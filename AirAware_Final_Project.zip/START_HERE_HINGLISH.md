# AirAware — yahin se start karo

**Ek hi project folder use karo.** Purane AirAware ZIPs ko mix mat karna.

## 1) App run karo

1. Python 3.11 install hona chahiye.
2. Is folder ko VS Code mein open karo.
3. Terminal mein project root (jahan `requirements.txt` hai) se run karo:

```bash
python -m pip install -r requirements.txt
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
```

4. Browser mein `http://127.0.0.1:8000` kholo. Server chal raha ho toh terminal ko band mat karna.

## 2) Pehle ye check karo

- `http://127.0.0.1:8000/api/health` — backend responds; ye live API ya AI ko test nahi karta.
- `http://127.0.0.1:8000/api/live-aqi?location=Delhi` — actual JSON response dekho. `mode: station` ka matlab WAQI station result mila. `mode: model_estimate` ka matlab model estimate hai, local monitoring-station reading nahi.
- UI mein AQI `168` default example **illustrative demo** hai; aaj ka AQI nahi.

## 3) Mentor demo ka order

1. Sports plan generate/show karo.
2. Activity ko Assembly mein badal kar suggestions compare karo.
3. Campus checklist ke 2 items tick karo.
4. Air-quality context card ka source, data type aur timestamp padho. API unavailable ho toh clearly bolo ki live source respond nahi kar raha; fake value mat dikhao.
5. “Ask AirAware” ko AI mat bolo jab tak response mein `ai_used: true` aur `Strands ... + Amazon Bedrock` clearly na aaye.

## 4) Live AQI setup (optional)

WAQI station feed ke liye apna token chahiye. `.env.example` ki copy `.env` banao aur `WAQI_API_TOKEN=...` sirf backend environment mein rakho. Token ko frontend, GitHub, screenshots ya chat mein kabhi paste mat karo. WAQI ka index Indian CPCB AQI se alag hai.

Open-Meteo/CAMS fallback bhi **model-estimated** hai, station measurement nahi aur Indian CPCB AQI bhi nahi. India-specific planner mein CPCB value alag se verify karke enter hoti hai.

## 5) Tests

```bash
python -m unittest tests.test_rules tests.test_live_aqi tests.test_api -v
python -m py_compile backend/app.py workshop_modules/01_first_agent.py workshop_modules/02_custom_aqi_tool.py workshop_modules/03_multi_agent_swarm.py
node --check frontend/script.js
```

## 6) AWS par deploy karna

Project mein AWS Elastic Beanstalk deployment ke liye Procfile aur source bundle tayyar hai, lekin deployment tumhare AWS account mein karna padega. Deploy complete hone aur public URL test hone se pehle “AWS deployed” mat kehna. Bedrock/Strands ke liye valid AWS credentials, correct region aur model access chahiye. Guide: `DEPLOYMENT_GUIDE.md`.

**Current verified boundary:** local backend + frontend routes and automated tests pass here. Real provider network response, WAQI token validity, Bedrock response, and public AWS deployment are not verified in this environment.
