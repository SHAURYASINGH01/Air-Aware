# AI assistance disclosure

ChatGPT assisted with project ideation, code drafting/organization, documentation, test planning and showcase materials. The project author should review and understand the code, run it in the intended environment, adapt it, and update this disclosure to match the actual contribution history and hackathon rules. Do not present AI-generated code as solely hand-written. Any third-party API is attributed in the UI/docs where used.
