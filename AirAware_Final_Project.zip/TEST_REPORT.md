# AirAware test report — 10 October 2026

## Checks run in this environment

- `python -m unittest tests.test_rules tests.test_live_aqi tests.test_api -v`: **11 tests passed**. Coverage includes CPCB category boundaries, activity-specific rules, mocked WAQI response parsing, rejection of a station response without a numeric index, unknown-location validation, safe model fallback selection, frontend asset serving, the health endpoint, and transparent AI-unavailable fallback.
- Python compile checks passed for `backend/app.py` and all three Strands workshop modules.
- `node --check frontend/script.js` passed.
- Frontend source includes explicit handling for source-fetch failure, a single initial AQI refresh call, and labels demo AQI 168 as illustrative.
- Local FastAPI smoke checks returned HTTP 200 for `/`, `/style.css`, `/script.js`, and `/api/health`.

## Not verified (important)

- A real Open-Meteo request returned an upstream-unavailable error in this execution environment. Do not claim a live model-context response until the browser/deployment shows actual provider data, source, and timestamp.
- No valid WAQI token is configured here, and no real WAQI station response was verified.
- Strands SDK/model access was not available here, so no actual Amazon Bedrock response or multi-agent Swarm run was verified.
- No public AWS deployment URL was created or tested in this environment.
- No campus-user pilot or measured impact study has been run.

## Safe claims

It is safe to say the source includes a working local planner UI, deterministic activity recommendations, a campus checklist, FastAPI routes, a WAQI parsing path, an Open-Meteo model-context path, and a transparent rules fallback. Eleven automated tests passed. Claim live station data, successful AI, or AWS deployment only after observing those exact successful states in the target environment.
