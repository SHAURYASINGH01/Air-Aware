import unittest
from backend.app import aqi_category, assessment_text, activity_recommendations

class AQIRuleTests(unittest.TestCase):
    def test_cpcb_bands(self):
        self.assertEqual(aqi_category(0)[0], "Good")
        self.assertEqual(aqi_category(50)[0], "Good")
        self.assertEqual(aqi_category(51)[0], "Satisfactory")
        self.assertEqual(aqi_category(100)[0], "Satisfactory")
        self.assertEqual(aqi_category(101)[0], "Moderate")
        self.assertEqual(aqi_category(200)[0], "Moderate")
        self.assertEqual(aqi_category(201)[0], "Poor")
        self.assertEqual(aqi_category(300)[0], "Poor")
        self.assertEqual(aqi_category(301)[0], "Very Poor")
        self.assertEqual(aqi_category(401)[0], "Severe")

    def test_assessment_is_clear_about_data(self):
        result = assessment_text(168, "sports")
        self.assertIn("Moderate", result)
        self.assertIn("Not live-verified", result)

    def test_activity_specific(self):
        self.assertIn("indoor", " ".join(activity_recommendations(250, "sports")).lower())
        self.assertTrue(activity_recommendations(250, "maintenance"))

if __name__ == "__main__":
    unittest.main()
