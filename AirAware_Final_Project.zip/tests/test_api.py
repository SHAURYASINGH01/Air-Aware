import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient
import backend.app as airaware


class APISmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(airaware.app)

    def test_frontend_and_assets_are_served(self):
        for path, expected_type in [
            ("/", "text/html"),
            ("/style.css", "text/css"),
            ("/script.js", "javascript"),
        ]:
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 200)
                self.assertIn(expected_type, response.headers.get("content-type", ""))

    def test_health_is_explicit_about_not_testing_live_services(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["ok"])
        self.assertIn("does not make", response.json()["note"])

    def test_live_aqi_rejects_unknown_location(self):
        response = self.client.get("/api/live-aqi", params={"location": "Unknown City"})
        self.assertEqual(response.status_code, 400)

    def test_ask_falls_back_honestly_if_ai_is_unavailable(self):
        with patch.object(airaware, "get_agent", side_effect=RuntimeError("test: Bedrock not configured")):
            response = self.client.post("/api/ask", json={
                "question": "What should we review?",
                "location": "Delhi",
                "aqi": 168,
                "source": "Illustrative sample",
                "activity": "sports",
                "mode": "single",
            })
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertFalse(payload["ai_used"])
        self.assertIn("Moderate", payload["answer"])
        self.assertIn("fallback", payload["mode"].lower())


if __name__ == "__main__":
    unittest.main()
