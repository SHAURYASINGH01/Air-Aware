import json
import unittest
from io import BytesIO
from unittest.mock import patch

from fastapi import HTTPException
import backend.app as airaware


class LiveAQITests(unittest.TestCase):
    def test_waqi_station_payload_is_normalized_and_token_is_not_returned(self):
        payload = {
            "status": "ok",
            "data": {
                "aqi": 137,
                "city": {"name": "Example station, Delhi", "url": "https://aqicn.org/city/example/", "geo": [28.61, 77.21]},
                "time": {"iso": "2026-10-10T12:00:00+05:30", "s": "2026-10-10 12:00:00"},
                "dominentpol": "pm25",
                "iaqi": {"pm25": {"v": 63.1}, "pm10": {"v": 94.2}, "no2": {"v": 14}},
                "attributions": [{"name": "Example EPA", "url": "https://example.gov/"}],
            },
        }
        with patch.object(airaware, "WAQI_API_TOKEN", "private-test-token"), patch.object(
            airaware, "urlopen", return_value=BytesIO(json.dumps(payload).encode("utf-8"))
        ) as mock_urlopen:
            result = airaware._fetch_waqi_station("Delhi")
        self.assertEqual(result["mode"], "station")
        self.assertEqual(result["index"], 137)
        self.assertEqual(result["pollutants"]["pm25"], 63.1)
        self.assertIn("not Indian CPCB", result["index_scale"])
        self.assertNotIn("private-test-token", json.dumps(result))
        request_url = mock_urlopen.call_args.args[0].full_url
        self.assertIn("private-test-token", request_url)

    def test_station_without_numeric_index_fails_closed(self):
        payload = {"status": "ok", "data": {"aqi": "-", "city": {"name": "Example"}}}
        with patch.object(airaware, "WAQI_API_TOKEN", "private-test-token"), patch.object(
            airaware, "urlopen", return_value=BytesIO(json.dumps(payload).encode("utf-8"))
        ):
            with self.assertRaises(RuntimeError):
                airaware._fetch_waqi_station("Delhi")

    def test_unknown_location_rejected(self):
        with self.assertRaises(HTTPException) as caught:
            airaware._fetch_waqi_station("Unknown City")
        self.assertEqual(caught.exception.status_code, 400)

    def test_missing_token_selects_modelled_fallback(self):
        fake_model = {
            "mode": "model_estimate",
            "current": {"time": "2026-10-10T12:00", "pm2_5": 24.2, "pm10": 40.4, "us_aqi": 77, "european_aqi": 19},
        }
        with patch.object(airaware, "WAQI_API_TOKEN", ""), patch.object(airaware, "_fetch_open_meteo", return_value=fake_model):
            result = airaware.live_aqi("Delhi")
        self.assertEqual(result["mode"], "model_estimate")
        self.assertIn("not a monitoring-station AQI", result["notice"])


if __name__ == "__main__":
    unittest.main()
