# Live AQI data setup (read this before presenting it as live)

AirAware supports two modes in its live-data card:

1. **Station feed (recommended for a real monitored index):** provider-reported WAQI reading from the nearest supported monitoring station. Requires your own WAQI token configured on the backend. The returned index uses the provider's index methodology and is **not the Indian CPCB National AQI**. The UI does not copy it into the CPCB planner.
2. **Model estimate (works without a key):** Open-Meteo/CAMS current model data for PM2.5, PM10, U.S. AQI and European AQI. This is a grid-scale model estimate, not a local monitor reading and not Indian CPCB AQI.

The browser asks for a refresh when opened, whenever the selected city changes, when you click **Refresh now**, and every 15 minutes while the page remains open. The source's own observation/model timestamp is displayed, so the UI does not imply the provider generated a new measurement every 15 minutes.

## Enable station-reported AQI

1. Visit the official [WAQI API page](https://aqicn.org/api/) and request your own token at [WAQI token request](https://aqicn.org/data-platform/token/).
2. Review the provider's current terms. The API requires attribution to the World Air Quality Index project and the originating provider/EPA; do not use it in paid/commercial products without permission, and do not redistribute/archive its feed contrary to its terms.
3. In the project root, copy `.env.example` to `.env`.
4. Replace `put_your_own_token_here` with your private token:

   ```dotenv
   WAQI_API_TOKEN=YOUR_PRIVATE_TOKEN
   ```

5. Keep `.env` private. It is already listed in `.gitignore`. Never paste the token into `frontend/script.js`, `index.html`, a public repository, a slide, a screenshot, or a chat.
6. Restart the backend:

   ```bash
   python -m pip install -r requirements.txt
   python -m uvicorn backend.app:app --host 0.0.0.0 --port 8000
   ```

7. Open `http://127.0.0.1:8000/api/health`. `waqi_token_configured` should be `true` (this only verifies the environment variable exists, not that the token works).
8. Open `http://127.0.0.1:8000/api/live-aqi?location=Delhi`. A successful station response has `"mode": "station"`, a station name, index, provider measurement timestamp, pollutants (where available), and source attributions. If it says `"mode": "model_estimate"`, the live station endpoint was not used; inspect the token, internet connection and station coverage.

## What the scale means

- The WAQI value must be described as a **WAQI/provider-reported index**, not Indian CPCB NAQI.
- Open-Meteo's `us_aqi` and `european_aqi` are separate international model indices. They are not Indian CPCB NAQI.
- The AirAware campus activity planner still uses a manually entered, source-and-timestamped Indian CPCB reading. Use the official [CPCB AQI portal](https://www.airquality.cpcb.gov.in/AQI/) to confirm India-specific readings. This prototype does not provide medical advice or official safety alerts.

## AWS deployment note

A static Amplify-only deployment cannot safely hold a private WAQI token or run this Python backend. For live station mode, deploy the **full repository** as a backend web service (for example, AWS Elastic Beanstalk) and add `WAQI_API_TOKEN` to service environment secrets. Do not put the token in the static ZIP. Configure the `WAQI_API_TOKEN` as a backend environment variable or secret in Elastic Beanstalk. Never put it in frontend code or commit it in a `.env` file. See [Elastic Beanstalk environment properties](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/environments-cfg-softwaresettings.html).

If you deploy only the static frontend, it continues to fetch Open-Meteo model estimates and must be described as modelled context, not station-based live AQI.
