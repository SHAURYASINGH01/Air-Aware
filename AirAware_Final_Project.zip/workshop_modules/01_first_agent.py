"""Workshop module 1: create a basic Strands agent with Amazon Bedrock.

Run from the project root after setting AWS credentials/region and installing requirements:
    python workshop_modules/01_first_agent.py
"""
import os
from strands import Agent
from strands.models import BedrockModel

model = BedrockModel(
    model_id=os.getenv("BEDROCK_MODEL_ID", "us.amazon.nova-lite-v1:0"),
    region_name=os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1",
    temperature=0.2,
    max_tokens=300,
)
agent = Agent(
    model=model,
    system_prompt="You are AirAware, a careful assistant. Do not invent live AQI data.",
)
print(agent("Explain in 3 simple sentences what an AQI value means for campus planning."))
