"""Workshop module 2: attach a custom tool to the agent.

Run from the project root after the workshop setup and dependency installation:
    python workshop_modules/02_custom_aqi_tool.py
"""
import os
from strands import Agent, tool
from strands.models import BedrockModel

@tool
def check_indian_aqi_band(aqi: int) -> str:
    """Return the common Indian CPCB AQI band for a user-provided value (0-500)."""
    if not isinstance(aqi, int) or isinstance(aqi, bool) or not 0 <= aqi <= 500:
        return "Invalid AQI: use a whole number from 0 to 500."
    if aqi <= 50: band = "Good"
    elif aqi <= 100: band = "Satisfactory"
    elif aqi <= 200: band = "Moderate"
    elif aqi <= 300: band = "Poor"
    elif aqi <= 400: band = "Very Poor"
    else: band = "Severe"
    return f"User-provided AQI {aqi} is in the {band} band. This is not live-verified."

model = BedrockModel(
    model_id=os.getenv("BEDROCK_MODEL_ID", "us.amazon.nova-lite-v1:0"),
    region_name=os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1",
    temperature=0.2,
    max_tokens=350,
)
agent = Agent(
    model=model,
    tools=[check_indian_aqi_band],
    system_prompt="Use check_indian_aqi_band whenever the user provides an AQI number. Never claim the reading is live.",
)
print(agent("Our campus AQI is 168. Explain the category in plain English and give cautious planning considerations."))
