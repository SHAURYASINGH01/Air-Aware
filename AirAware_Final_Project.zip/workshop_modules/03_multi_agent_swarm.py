"""Workshop module 3: bounded specialist-agent swarm for AirAware.

This intentionally keeps the output small and the number of handoffs bounded.
Run from project root after setting up Strands + Amazon Bedrock:
    python workshop_modules/03_multi_agent_swarm.py
"""
import os
from strands import Agent, tool
from strands.models import BedrockModel
from strands.multiagent import Swarm

@tool
def check_indian_aqi_band(aqi: int) -> str:
    """Check the common Indian CPCB AQI band for a user-provided integer 0-500."""
    if not isinstance(aqi, int) or isinstance(aqi, bool) or not 0 <= aqi <= 500:
        return "Invalid AQI; enter a whole number from 0 to 500."
    if aqi <= 50: band = "Good"
    elif aqi <= 100: band = "Satisfactory"
    elif aqi <= 200: band = "Moderate"
    elif aqi <= 300: band = "Poor"
    elif aqi <= 400: band = "Very Poor"
    else: band = "Severe"
    return f"AQI {aqi}: {band}. User-provided and not live-verified."

model = BedrockModel(
    model_id=os.getenv("BEDROCK_MODEL_ID", "us.amazon.nova-lite-v1:0"),
    region_name=os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1",
    temperature=0.2,
    max_tokens=350,
)
analyst = Agent(
    name="aqi_analyst",
    description="Checks the user-provided AQI band and explains limitations.",
    model=model,
    tools=[check_indian_aqi_band],
    system_prompt="Check the number with the tool. Then hand off to campus_planner with the verified-from-tool band and activity.",
)
planner = Agent(
    name="campus_planner",
    description="Suggests activity-specific campus planning options.",
    model=model,
    tools=[check_indian_aqi_band],
    system_prompt="Provide cautious options for outdoor sports. Do not give medical advice. Then hand off to campus_communicator.",
)
communicator = Agent(
    name="campus_communicator",
    description="Writes the final concise campus message and checklist.",
    model=model,
    system_prompt="Give the final short response plus three checklist items. State that AQI is user-provided, not live-verified. Do not hand off further.",
)
swarm = Swarm(
    [analyst, planner, communicator],
    entry_point=analyst,
    max_handoffs=2,
    max_iterations=4,
    execution_timeout=45.0,
    node_timeout=20.0,
)
result = swarm("Our campus AQI is 168. The activity is outdoor sports. Prepare a cautious planning note.")
print(f"Swarm status: {result.status}")
print("Agent route:", " -> ".join(getattr(node, "node_id", "agent") for node in getattr(result, "node_history", [])))
print(result)
