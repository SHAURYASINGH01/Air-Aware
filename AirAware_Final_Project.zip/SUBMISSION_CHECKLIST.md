# AirAware — Environmental Hacks submission checklist

## Rule checks that matter
- [ ] Confirm every team member meets the official eligibility rules and has completed their own required registration/verification.
- [ ] Make sure the submitted work was built during the hackathon window; the rules exclude pre-existing projects.
- [ ] Demonstrate actual AWS usage in the video. A mention in the README alone is not enough. Use a successful Bedrock/Strands response or a real AWS deployment, and capture the working state on camera.
- [ ] Make the full source repository public; keep `.env`, API tokens, AWS credentials, personal data, and secret files out of it.
- [ ] Upload a YouTube demo under 3 minutes (public or unlisted) and test the link in a signed-out browser.
- [ ] Submit the short write-up covering the problem, what you built, and exactly where AWS fits; disclose AI coding tools and credit third-party sources/libraries.

## Demo sequence
- [ ] State the campus-coordinator problem and the hypothesis to be tested.
- [ ] Generate an activity plan with a clearly labelled illustrative AQI if no trusted CPCB reading is available.
- [ ] Switch Sports → Assembly and show the activity-specific recommendations change.
- [ ] Tick checklist items and show the progress indicator.
- [ ] Show the air-quality context card only as station-reported/model-estimated when the actual response provides the source/time. If unavailable, say so; do not invent live values.
- [ ] Show a successful real AWS integration/deployment. If Bedrock responds, the API should report `ai_used: true` and `Strands ... + Amazon Bedrock`; otherwise do not call the response AI.
- [ ] Explain that WAQI provider indices, Open-Meteo/CAMS estimates, and Indian CPCB AQI are separate data types.
- [ ] End with limitations: no medical advice, no official alert, and no measured campus-user impact yet.

## Before publishing
- [ ] Check `git status` and inspect all files before committing.
- [ ] Confirm `.env` is ignored and no real tokens/credentials are present anywhere in screenshots or slides.
- [ ] Follow the current WAQI and Open-Meteo attribution/usage terms.
- [ ] Verify the current event form and deadline on the official Environmental Hacks submission page.
- [ ] Keep submission confirmation after submitting.
