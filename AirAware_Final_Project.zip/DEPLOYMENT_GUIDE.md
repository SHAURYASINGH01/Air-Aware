# Deployment guide

## Fast local demo

1. If needed, copy `.env.example` to `.env`. Leave `WAQI_API_TOKEN` empty unless you have a real token.
2. Run `python -m pip install -r requirements.txt`.
3. Run `python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000`.
4. Open `http://127.0.0.1:8000`.
5. Check `http://127.0.0.1:8000/api/health` and `http://127.0.0.1:8000/api/live-aqi?location=Delhi`.

## Deploy the full-stack app to AWS Elastic Beanstalk

This project includes a `Procfile` and top-level `requirements.txt` for the Elastic Beanstalk Python platform. AWS App Runner stopped accepting new customers on April 30, 2026, so use Elastic Beanstalk for a new AWS account instead.

1. Sign in to the [AWS Console](https://console.aws.amazon.com/elasticbeanstalk/) and open **Elastic Beanstalk**.
2. Choose **Create application**. Name it `AirAware` and create a **Web server environment**.
3. Choose the **Python** platform and a supported Python 3.11+ branch if available.
4. Under **Application code**, choose **Upload your code** and upload `AirAware_Final_Project.zip`. This archive is prepared as a source bundle: `requirements.txt`, `Procfile`, and `backend/` are at the ZIP root, not inside an extra parent directory.
5. Choose a single-instance environment / eligible low-cost instance option where available. Review the estimated cost, choose the required service role, then create the environment.
6. Wait for the environment health to become **Green**. Open its public URL. Test `/api/health` and `/api/live-aqi?location=Delhi`.
7. For station-reported data, add `WAQI_API_TOKEN` only in the environment's configuration/secrets after obtaining your own token. Keep it out of GitHub and the ZIP. Without it, AirAware may show a clearly labelled Open-Meteo/CAMS model estimate.
8. Only describe the app as deployed after the AWS URL successfully loads. Showing the successful AWS-hosted app in the demo can demonstrate the required AWS usage.

AWS documentation:
- [Create an Elastic Beanstalk application/environment](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/environments-create-wizard.html)
- [Python platform and Procfile](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/python-configuration-procfile.html)
- [Source bundle structure](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/applications-sourcebundle.html)

## Optional AI integration

The Strands/Bedrock path requires working AWS credentials/instance permissions, a supported region, and model access. A working `/api/health` endpoint does not prove Bedrock works. Only claim AI is operational when an actual `/api/ask` request confirms it.

## Before the demo

- Verify current data and show source/time. Do not call an illustrative or model-estimated value a live station reading.
- WAQI/provider index, Open-Meteo/CAMS estimates, and Indian CPCB AQI are different data types/scales; keep the distinctions visible.
- AirAware is a student planning prototype, not medical advice or an official alert system.
- Monitor AWS costs and delete the environment when you no longer need it.
