# AirAware — Final Showcase Script & Mentor Q&A

## The 1-sentence pitch
**AirAware helps campus coordinators turn air-quality information into an activity review and a shared checklist—not just another AQI display.**

## 15-second intro
"Hi, I'm presenting AirAware, a campus air-safety planning prototype. It combines an activity-based planning workflow and a campus checklist with a separate air-quality context card that shows its source and data type."

## 30-second pitch
"A campus team may see an air-quality number but still has to review sports, assembly, commute, or outdoor work. AirAware lets a user enter an Indian CPCB AQI value, choose an activity, view cautious planning prompts, and track a review checklist. A separate card can fetch Open-Meteo/CAMS model-based air-quality context when internet access is available. The current project also has an optional backend path for a WAQI station-reported index when a private token is configured. These feeds use different definitions and are deliberately not copied into the Indian CPCB planner automatically."

## Live demo sequence (about 3 minutes)

### 0:00–0:20 — Problem and target user
Say: "The target user I'm testing is a campus coordinator planning an activity before it starts. I want to test whether the activity-specific plan and checklist improve the process beyond simply opening an AQI app. That value is a hypothesis, not a proven outcome yet."

### 0:20–0:55 — Show the air-quality context card
1. Open `http://127.0.0.1:8000` after starting the backend, or open `frontend/index.html` for a UI-only preview.
2. Click **Refresh now** in the air-quality context card.
3. Point out the provider, timestamp and data-type label.
4. If it says **Open-Meteo / CAMS model estimate**, say: "This is current model-based context, not a measurement from a nearby roadside monitoring station. The model time is shown by the provider."
5. If a full backend with a valid WAQI token returns **station mode**, say: "This is a provider-reported WAQI station index and its station/time attribution. It is not Indian CPCB National AQI, so I don't use this number as the CPCB planner input."
6. If the request fails, say: "The source isn't responding in this environment right now; I won't invent a live value. I'll demonstrate the planner with a clearly marked example instead."

### 0:55–1:30 — Show the CPCB planner
1. The planner expects an **Indian CPCB AQI value entered by the user**, with source and time noted separately.
2. If you have verified a current CPCB/SAMEER station reading, enter it and identify its source/time.
3. If the official portal/feed is unavailable, click the clearly labelled **demo example AQI 168** (or enter 168) and state: "This is illustrative demo data, not a current city reading."
4. Select **Sports**, generate the plan, then switch to **Assembly** and generate again.
5. Say: "The rule-based layer keeps the Indian AQI band and basic planning prompts deterministic. Suggestions are not medical advice or official alerts."

### 1:30–1:55 — Show the campus checklist
1. Tick two items and point to the progress indicator.
2. If available, show copy/download/save-plan controls.
3. Say: "The proposed benefit is helping a coordinator record a review and share a consistent plan. We still need campus-user feedback to prove this is useful."

### 1:55–2:25 — Show AI only if it really ran
1. Use **Ask AirAware** only if the FastAPI backend is running.
2. Prompt: `For AQI 168 and outdoor sports, what should our campus review?`
3. Claim a real AI call only if the response explicitly reports **Strands single agent + Amazon Bedrock** and `ai_used: true`.
4. If the interface reports **Rules-based fallback (AI unavailable)**, say: "The rules fallback works, but the Bedrock call did not succeed in this run."
5. Do not select/show the swarm as a working feature unless you have received and checked an actual successful swarm response in the target environment.

### 2:25–3:00 — Limitations and next step
Say: "The Indian CPCB planner still uses a user-entered value. Open-Meteo/CAMS is separate modelled context; the optional WAQI station feed needs a valid private server-side token and uses a different index. I haven't verified a live provider response or public AWS deployment in this test environment. Next I want to validate the feed and stale-data handling, verify the Bedrock call, and run a small pilot with a campus coordinator."

## If you only have 60 seconds
"AirAware is a campus activity-planning prototype. It lets someone enter an Indian CPCB AQI value, choose sports or assembly, and receive cautious planning prompts plus a checklist. A separate card can fetch Open-Meteo model-based air-quality context; a backend option supports WAQI station data when a private token and station response are available. These sources are labelled separately because their indices aren't interchangeable. I still need to verify live provider calls and test whether campus coordinators find the workflow useful."

## Architecture, in plain English
- **Frontend:** HTML, CSS and JavaScript; activity planner, context card, checklist and assistant panel.
- **Model-based context:** Open-Meteo/CAMS API for PM2.5, PM10 and U.S./European AQI estimates. These are grid/model estimates, not Indian CPCB station NAQI.
- **Optional station feed:** FastAPI backend calls WAQI when `WAQI_API_TOKEN` is configured. Its provider index is not Indian CPCB NAQI; keep the token server-side.
- **CPCB planner:** User-entered Indian AQI value feeds a deterministic rule/tool, with activity-specific planning prompts and warnings that it is not medical advice.
- **AI workflow:** Strands Agents SDK with Amazon Bedrock is optional. The API labels whether an actual AI response succeeded or whether it used rules fallback.
- **Optional swarm:** Analyst → Planner → Communicator. Treat it as unverified until you test a successful run in your workshop environment.

## Judge questions and concise answers

### "You are already outside. Why check AQI?"
"Looking outside doesn't reveal fine-particle concentration reliably. But I agree an AQI number alone doesn't create value. AirAware targets a campus coordinator who plans an activity in advance; I want to test whether the activity-specific checklist makes that planning easier."

### "Other apps already show AQI. What is unique?"
"AQI display is not unique. My hypothesis is the campus workflow—activity-specific review, a shared checklist, and clear source/time handling. I haven't proven the differentiator yet; I'd validate it with campus coordinators before claiming impact."

### "Does it show real AQI?"
"The separate context card can fetch Open-Meteo/CAMS model estimates when online. In the full backend, a valid WAQI token and supported station response enable a provider-reported station index. Neither is Indian CPCB National AQI. The Indian CPCB planner still takes a separate user-entered value. Live calls have to be verified in the deployment environment."

### "CPCB website is not working. What do you do?"
"I don't invent a reading or silently substitute a different index. I try another official CPCB/SAMEER access route if available. If I can't verify the source and time, I label the input as a demo value and clearly state that the planner run is illustrative."

### "How do you know recommendations are correct?"
"They're conservative, rule-based planning prompts—not medical advice or official alerts. I'd validate them against official guidance and get review from campus safety coordinators before relying on them."

### "Why use AI? Can rules do this?"
"Rules should own the category and baseline planning logic because those need to be predictable. AI is only intended to explain the plan in plain language. I'll keep it only if it adds measurable value beyond the rules-based result."

### "What have you implemented?"
"The frontend, activity-based rule planner, checklist, FastAPI endpoints, an AQI assessment tool, a separate model-context fetch path, optional WAQI backend integration, and an optional Strands/Bedrock code path with a transparent fallback. Eleven automated unit/API smoke tests pass, including mocked station-payload parsing and local route checks. The external provider response, Bedrock call, swarm run, and AWS deployment still need verification in the target environment."

### "How will you validate impact?"
"Pilot with a few campus coordinators. Compare their existing process with AirAware and measure time to complete a review, source/time verification, checklist completion, usefulness ratings, and how often they edit or reject suggestions. I don't have pilot results yet."

### "What is the biggest limitation?"
"I haven't confirmed a real provider response in the target network, live Bedrock/Swarm execution, or a public AWS deployment. The context feed and Indian CPCB planner are separate by design, and campus impact isn't tested yet."

### "What did AI help with?"
"ChatGPT assisted with ideation, code drafting and organisation, documentation, test planning and showcase materials. I am reviewing and testing the implementation, and I will disclose that assistance in the project write-up."

## Before showing it
- [ ] Open the app and make sure the correct page loads.
- [ ] Click **Refresh now** and read the mode/provider label and timestamp aloud.
- [ ] If the fetch fails, don't call the data live; use the labelled demo example.
- [ ] Generate a sports plan and an assembly plan.
- [ ] Tick and reset the checklist.
- [ ] Ask the AI question only if the backend is running; verify the response mode.
- [ ] Use swarm only after a successful run.
- [ ] Keep the slide deck and a local copy as backup.
- [ ] Never show API tokens, AWS credentials or `.env` contents.
