# AirAware — Quick Showcase Cheat Sheet

## One line
AirAware helps campus coordinators turn air-quality information into an activity review and shared checklist.

## Demo in 3 minutes
1. **Context card:** click Refresh now. Name the provider and say whether it is a model estimate or a station-reported index. Mention its timestamp.
2. **CPCB planner:** enter a verified Indian CPCB value with source/time, or use the clearly labelled example AQI 168 if current source is unavailable.
3. **Switch activity:** Sports → Assembly; compare prompts.
4. **Checklist:** tick two items and show progress/copy/save if available.
5. **AI:** only claim success if the response says Strands + Amazon Bedrock and reports `ai_used: true`.
6. **Close:** explain that source validation, Bedrock execution and AWS deployment must be verified in the target environment.

## Never mix these data types
- **Indian CPCB AQI:** value entered separately into the planner after source verification.
- **Open-Meteo/CAMS model estimate:** PM values and U.S./European AQI; not a local station measurement and not Indian CPCB NAQI.
- **WAQI provider index:** station-reported index if the backend has a valid token and station response; not Indian CPCB NAQI.
- **AQI 168 example:** illustrative, not current city data.

## Three judge answers
**Why not just look outside?** "Looking outside doesn't reliably reveal PM2.5 concentration. The real question is whether this activity-planning workflow helps a coordinator; that needs a campus pilot."

**What is different?** "Not AQI display itself. The hypothesis is activity-specific planning plus a shared checklist and source/time transparency."

**What works now?** "The planner, activity prompts, checklist, data-source separation, model-context request path, optional WAQI backend route, and rules fallback. Live external calls, Bedrock/Swarm, and deployment need verification in the target environment."

## If CPCB site fails
Don't substitute an unlabelled reading. Use another official access route if available; otherwise demonstrate with the labelled sample and say it is illustrative.
