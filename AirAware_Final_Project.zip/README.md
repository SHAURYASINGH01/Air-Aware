# AirAware — Campus Air Safety Planner

AirAware helps campus teams translate air-quality information into activity-planning prompts and a shared checklist. It contains a responsive HTML/CSS/JavaScript frontend, FastAPI backend, source/timestamp display, optional station-reported AQI via the WAQI API, Open-Meteo model-estimate fallback, and optional Strands Agents/Amazon Bedrock workshop modules.

## Current data modes

- **Station mode:** if `WAQI_API_TOKEN` is configured on the backend and a nearby station returns a numeric value, AirAware shows the provider-reported station index, station name, source timestamp, pollutant values where available, and returned attributions. It is a WAQI/provider index, **not the Indian CPCB National AQI**. It is never copied into the India CPCB planner.
- **Model mode:** if no WAQI token is configured or the station feed fails, AirAware shows Open-Meteo/CAMS model estimates (PM2.5, PM10, U.S. AQI, European AQI), labelled as estimates and not local station measurements.
- **CPCB planner:** the user manually enters a verified Indian CPCB AQI and its source/time. This remains separate because AQI scales and calculation methods differ.

Live data is refreshed on page load, on location change, on manual refresh, and every 15 minutes while the page remains visible. The source-provided measurement/model timestamp is displayed; the app does not claim that upstream data is regenerated every 15 minutes.

## Start locally

1. Python 3.11 is recommended. For the easiest Windows start, double-click `RUN_AIRAWARE.bat`; it creates a virtual environment, installs the requirements, and starts the server. To configure station mode later, copy `.env.example` to `.env` and add your own token privately.
2. Install requirements: `python -m pip install -r requirements.txt`.
3. Start: `python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000`.
4. Open `http://127.0.0.1:8000`.
5. Check `http://127.0.0.1:8000/api/health`; this says whether a token is configured but does not validate the token.
6. Check `http://127.0.0.1:8000/api/live-aqi?location=Delhi`. `mode=station` means the station provider returned data; `mode=model_estimate` means the model fallback is being shown.

Read `START_HERE_HINGLISH.md` for the quickest beginner setup, `LIVE_AQI_SETUP.md` for source/token details, and `DEPLOYMENT_GUIDE.md` before attempting AWS hosting.

## Test status

Local unit/API smoke tests cover planner rules, mocked WAQI parsing, source-scale labeling, frontend asset serving, and a transparent rules fallback. They do not prove external APIs, real Strands/Bedrock calls, or AWS deployment are working. See `TEST_REPORT.md` for the exact checks and limitations.

## Tests

```bash
python -m unittest tests.test_rules tests.test_live_aqi tests.test_api -v
python -m py_compile backend/app.py workshop_modules/01_first_agent.py workshop_modules/02_custom_aqi_tool.py workshop_modules/03_multi_agent_swarm.py
```

The live-source tests use a mocked provider payload; they do not prove that the external provider or your token is working. Real API connectivity must be checked in your own environment.

## Limitations

- Live WAQI station mode requires your own valid token and may have no numeric reading for a given nearby station at some times.
- Opening `frontend/index.html` directly provides a frontend-only preview that can request Open-Meteo model estimates. A private WAQI token requires the Python backend and must stay server-side.
- The WAQI and Open-Meteo indices are not the Indian CPCB National AQI. Always verify Indian AQI on the official CPCB portal for local decisions.
- The Strands/Bedrock response requires successful AWS region, credentials and model access. Health check alone does not validate model access.
- AirAware is a student planning prototype, not a medical-advice service or official alert system.
