@echo off
setlocal
cd /d "%~dp0"

if not exist .venv\Scripts\python.exe (
  echo Creating Python virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 (
    echo Could not create environment. Install Python 3.11 or newer, then retry.
    pause
    exit /b 1
  )
  call .venv\Scripts\activate.bat
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Package installation failed. Check internet connection and the error above.
    pause
    exit /b 1
  )
) else (
  call .venv\Scripts\activate.bat
)

if "%AWS_REGION%"=="" set AWS_REGION=us-east-1
if "%AWS_DEFAULT_REGION%"=="" set AWS_DEFAULT_REGION=%AWS_REGION%
if "%BEDROCK_MODEL_ID%"=="" set BEDROCK_MODEL_ID=us.amazon.nova-lite-v1:0

echo.
echo AirAware will open at http://127.0.0.1:8000
echo Single-agent and swarm modes need working AWS Bedrock access.
echo Without it, the AQI planner still works and assistant responses show rules-based fallback.
start "AirAware" cmd /c "timeout /t 3 ^>nul ^& start http://127.0.0.1:8000"
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
pause
